
------------------------------------------------------------
This resource has been created by Orman Clark for PremiumPixels.com
------------------------------------------------------------

TERMS OF USE:

All resources made available on Premium Pixels, including but not limited to, icons, images, brushes, shapes, layer styles, layered PSD�s, patterns, textures, web elements and themes are free for use in both personal and commercial projects.

You may freely use our resources, without restriction, in software programs, web templates and other materials intended for sale or distribution. No attribution or backlinks are required, but any form of spreading the word is always appreciated!

You are not permitted to make the resources found on Premium Pixels available for distribution elsewhere �as is� without prior consent.


Orman Clark for PremiumPixels.com
_________________________
www.premiumpixels.com
www.ormanclark.com

